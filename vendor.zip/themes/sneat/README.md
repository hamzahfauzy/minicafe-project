# Icon menggunakan bx

 - cara penggunaan : bx-user