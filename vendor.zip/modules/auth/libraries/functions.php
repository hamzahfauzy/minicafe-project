<?php

\Core\Request::addPublicRoute('auth/login');