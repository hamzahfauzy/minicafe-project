<?php

return [
    'login' => 'Masuk',
    'username' => 'Nama Pengguna',
    'password' => 'Kata Sandi',
    'remember_me' => 'Ingat Saya',
    'forgot_password' => 'Lupa Kata Sandi',
    'not_a_member' => 'Bukan Pengguna',
    'sign_up' => 'Daftar',
];