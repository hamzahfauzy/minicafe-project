<?php

return [
    'login_fail' => 'Login Gagal! Nama Pengguna atau Kata Sandi tidak valid'
];