<?php

return [
    'login' => 'Login',
    'username' => 'Username',
    'password' => 'Password',
    'remember_me' => 'Remember Me',
    'forgot_password' => 'Forgot Password',
    'not_a_member' => 'Not a Member',
    'sign_up' => 'Sign Up',
];