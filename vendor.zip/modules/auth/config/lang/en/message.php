<?php

return [
    'login_fail' => 'Login Fail! Wrong username or password'
];