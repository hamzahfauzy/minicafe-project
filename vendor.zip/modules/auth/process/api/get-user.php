<?php

use Core\Response;

return Response::json(auth(), 'user retireved');
