<?php 

return [
    'module_name' => 'SaaS',
    'organizations' => 'Organisasi',
    'plans' => 'Rencana',
    'invoices' => 'Faktur',
    'subscriptions' => 'Langganan'
];