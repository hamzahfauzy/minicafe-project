<?php 

return [
    'module_name' => 'SaaS',
    'saas_organizations' => 'Organisasi',
    'saas_invoices' => 'Faktur',
    'saas_plans' => 'Rencana',
    'saas_subscriptions' => 'Langganan',
];