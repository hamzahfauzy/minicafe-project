<?php 

return [
    'module_name' => 'SaaS',
    'organizations' => 'Organizations',
    'plans' => 'Plans',
    'invoices' => 'Invoices',
    'subscriptions' => 'Subscriptions'
];