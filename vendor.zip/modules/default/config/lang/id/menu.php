<?php

return [
    'module_name' => 'Default',
    'dashboard' => 'Dashboard',
    'users and roles' => 'Pengguna dan Peran',
    'users' => 'Pengguna',
    'roles' => 'Peran',
    'media' => 'Media',
    'settings' => 'Pengaturan',
    'calendar' => 'Kalender',
];