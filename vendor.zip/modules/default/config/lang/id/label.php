<?php

return [
    'users'      => 'Pengguna',
    'users_name' => 'Nama',
    'users_username' => 'Nama Pengguna',
    'users_password' => 'Kata Sandi',

    'roles'      => 'Peran',
    'roles_name' => 'Nama',
    'role_routes'=> 'Rute Peran',
    'role_routes_role'=> 'Peran',
    'role_routes_path'=> 'Rute',
    'role_order_number'=> 'No. Urut',

    'user_roles' => 'Peran Pengguna',
    'user' => 'Pengguna',
    'user_roles_user' => 'Pengguna',
    'user_roles_role' => 'Peran',

    'media' => 'Media',
    'file_name' => 'Nama File',
    'file' => 'File',
    'created_by' => 'Pembuat',
    'created_at' => 'Tanggal',
    
    'profile' => 'Profil',
    'calendar' => 'Kalender',
    'record_type' => 'Tipe Record',
    'settings' => 'Pengaturan',
    'title' => 'Judul',
    'description' => 'Deskripsi',
    'start_at' => 'Mulai',
    'end_at' => 'Berakhir',
    'visibility' => 'Visibilitas',
];