<?php

return [
    'home' => 'Beranda',
];