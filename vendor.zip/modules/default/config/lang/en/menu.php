<?php

return [
    'module_name' => 'Default',
    'dashboard' => 'Dashboard',
    'users and roles' => 'Users and Roles',
    'users' => 'Users',
    'roles' => 'Roles',
    'media' => 'Media',
    'settings' => 'Settings',
    'calendar' => 'Calendar',
];