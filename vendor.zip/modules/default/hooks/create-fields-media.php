<?php

unset($fields['original_name']);
unset($fields['created_by']);
unset($fields['created_at']);

return $fields;