<?php

$data['created_by'] = auth()->id;