<?php

unset($fields['user_id']);
return $fields;