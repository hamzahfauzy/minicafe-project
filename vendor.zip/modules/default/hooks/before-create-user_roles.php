<?php

$data['user_id'] = $_GET['filter']['user_id'];