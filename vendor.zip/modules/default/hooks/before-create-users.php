<?php

$data['password'] = md5($data['password']);