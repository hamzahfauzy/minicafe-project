<?php

$data['role_id'] = $_GET['filter']['role_id'];