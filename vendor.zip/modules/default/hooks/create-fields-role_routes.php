<?php

unset($fields['role_id']);
return $fields;