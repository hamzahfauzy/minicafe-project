<?php 

return [
    'module_name' => 'Manajemen',
    'mc_customers' => 'Pelanggan',
    'mc_categories' => 'Kategori',
    'mc_sections' => 'Bagian',
    'mc_products' => 'Produk',
    'mc_orders' => 'Pesanan',
    'mc_cafes' => 'Cafe',
    'waiters' => 'Pelayan',
    'kitchens' => 'Dapur',
    'mc_order_items' => 'Antrian',
    'users' => 'Pengguna',
    'operators' => 'Operator',
    'reports' => 'Laporan',
    'recap' => 'Rekapitulasi'
];