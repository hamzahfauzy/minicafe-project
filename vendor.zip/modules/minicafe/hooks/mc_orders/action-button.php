<?php

return '<a href="'.routeTo('minicafe/orders/detail', ['code' => $data->code]).'" class="btn btn-sm btn-success"><i class="fas fa-eye"></i> Detail</a>';