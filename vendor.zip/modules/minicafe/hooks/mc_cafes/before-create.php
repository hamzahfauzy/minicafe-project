<?php

use Core\Session;

$data['organization_id'] = Session::get('organization')->id;