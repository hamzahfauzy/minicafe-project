<?php

unset($fields['password']);

$fields['cafe'] = [
    'label' => 'Cafe',
    'type' => 'text'
];

return $fields;