<?php

return [
    'home'   => 'Home',
    'create' => 'Create',
    'edit'   => 'Edit',
    'delete' => 'Delete',
    'back'   => 'Back',
    'view'   => 'View',
    'confirm_msg' => 'are you sure ?',
    'choose' => '- Choose -',
    'action_button' => 'Action',
    'created_at' => 'Created at',
    'created_by' => 'Created by',
    'updated_by' => 'Updated by',
    'updated_at' => 'Updated at',
];