<?php

return [
    'home'   => 'Beranda',
    'create' => 'Tambah',
    'edit'   => 'Edit',
    'delete' => 'Hapus',
    'back'   => 'Kembali',
    'view'   => 'Lihat',
    'confirm_msg' => 'apakah anda yakin akan menghapus data ini ?',
    'choose' => '- Pilih -',
    'action_button' => 'Aksi',
    'created_at' => 'Dibuat Pada',
    'created_by' => 'Dibuat Oleh',
    'updated_by' => 'Diubah Oleh',
    'updated_at' => 'Diubah Pada',
];